﻿namespace AtyBackend.Domain.Entities
{
    public class WeatherStation : Entity
    {
        public string Name { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public double Altitude { get; set; }
        public bool IsPrivate { get; set; }
        public string? RefreshToken { get; set; }

        public List<Partners>? Partners { get; set; }
        public List<Sensors> WeatherStationSensors { get; set; }
        public List<WeatherStationMaintainers> WeatherStationMaintainers { get; set; }
        public List<WeatherStationUsers>? WeatherStationUsers { get; set; }
    }
}
